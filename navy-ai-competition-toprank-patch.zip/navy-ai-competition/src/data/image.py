"""이미지: 클래스별 폴더 스캔 + Dataset (3채널)."""
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as T
from src.utils.log import ok

EXT = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def scan_images(source_dir, cfg):
    valid = cfg["data"]["valid_classes"]
    exclude = cfg["data"].get("exclude") or []
    rows = []
    for p in Path(source_dir).rglob("*"):
        if p.is_file() and p.suffix.lower() in EXT:
            cls = p.parent.name
            if cls in exclude or (valid and cls not in valid):
                continue
            rows.append({"path": str(p), "uid": f"{cls}/{p.name}", "class_name": cls, "file_id": len(rows)})
    df = pd.DataFrame(rows)
    if len(df) == 0:
        raise RuntimeError(f"이미지가 없습니다: {source_dir}")
    ok(f"이미지 {len(df)}개 / 클래스 {sorted(df['class_name'].unique())}")
    return df


def make_transform(cfg, train):
    size = cfg["image"]["img_size"]
    aug = cfg["image"]["augment"] and train
    tfs = [T.Resize((size, size))]
    if aug:
        tfs += [T.RandomHorizontalFlip(), T.RandomRotation(10)]
    tfs += [T.ToTensor()]
    return T.Compose(tfs)


class ImageDataset(Dataset):
    def __init__(self, df, cfg, augment=False):
        self.df = df.reset_index(drop=True); self.tf = make_transform(cfg, augment)

    def __len__(self): return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        img = Image.open(row["path"]).convert("RGB")
        return self.tf(img), torch.tensor(int(row["target"]), dtype=torch.long)
