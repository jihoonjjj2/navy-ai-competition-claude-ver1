"""표/시퀀스 CSV: 로드 + 라벨/id 추정 + 특성공학(+id별 집계)."""
from pathlib import Path
import numpy as np
import pandas as pd
from src.utils.log import ok, warn, info, stat
from src.detect import guess_label_col, guess_id_col

LAT = ["lat", "latitude", "y_lat"]
LON = ["lon", "longitude", "x_lon"]
SOG = ["sog", "speed", "speed_over_ground"]
COG = ["cog", "course", "heading"]


def _find(cols, names):
    for c in cols:
        if c.lower() in names:
            return c
    return None


def load_csv(source_dir, cfg, which="train"):
    if which == "test" and cfg["data"].get("test_csv"):
        path = cfg["data"]["test_csv"]
    else:
        csvs = sorted(Path(source_dir).glob("*.csv")) + sorted(Path(source_dir).rglob("*.csv"))
        # train/test 이름 우선
        train_like = [c for c in csvs if "train" in c.name.lower()]
        test_like = [c for c in csvs if "test" in c.name.lower()]
        if which == "test":
            if not test_like:
                return None, None, None
            path = test_like[0]
        else:
            path = (train_like or csvs)[0]
    df = pd.read_csv(path)
    label_col = cfg["data"].get("label_col") or (guess_label_col(df) if which == "train" else None)
    id_col = cfg["data"].get("id_col") or guess_id_col(df)
    ok(f"[{which}] CSV 로드: {Path(path).name} | shape {df.shape}")
    if which == "train":
        info(f"라벨 컬럼 추정: {label_col} | id 컬럼 추정: {id_col}")
    return df, label_col, id_col


def _haversine_path(lat, lon):
    R = 6371.0
    lat, lon = np.radians(lat), np.radians(lon)
    dlat, dlon = np.diff(lat), np.diff(lon)
    a = np.sin(dlat / 2) ** 2 + np.cos(lat[:-1]) * np.cos(lat[1:]) * np.sin(dlon / 2) ** 2
    return float(np.sum(2 * R * np.arcsin(np.sqrt(np.clip(a, 0, 1)))))


def engineer_sequence(df, id_col, label_col):
    """id별 시계열 → 한 행(통계 특성)으로 집계 (AIS/센서용). 쉽게 수정 가능."""
    if id_col is None:
        raise RuntimeError("시퀀스 집계에는 id 컬럼이 필요합니다. configs의 id_col 지정.")
    num_cols = [c for c in df.select_dtypes(include="number").columns
                if c not in (id_col,) and c != label_col]
    latc, lonc = _find(df.columns, LAT), _find(df.columns, LON)
    sogc, cogc = _find(df.columns, SOG), _find(df.columns, COG)
    rows = []
    for uid, g in df.groupby(id_col):
        r = {"id": uid, "n_points": len(g)}
        for c in num_cols:                       # 기본: 모든 수치 컬럼 통계
            r[f"{c}_mean"] = g[c].mean(); r[f"{c}_std"] = g[c].std()
            r[f"{c}_min"] = g[c].min(); r[f"{c}_max"] = g[c].max()
        if latc and lonc:                        # 공간 특성
            r["lat_range"] = g[latc].max() - g[latc].min()
            r["lon_range"] = g[lonc].max() - g[lonc].min()
            r["path_km"] = _haversine_path(g[latc].values, g[lonc].values)
        if sogc:                                 # 속도 특성
            r["stop_ratio"] = float((g[sogc] < 1).mean())
            r["slow_ratio"] = float((g[sogc] < 5).mean())
        if cogc:                                 # 침로 변화
            r["course_change_std"] = float(np.std(np.diff(g[cogc].values))) if len(g) > 1 else 0.0
        if label_col and label_col in g.columns:
            r[label_col] = g[label_col].iloc[0]
        rows.append(r)
    out = pd.DataFrame(rows)
    stat(f"id별 집계: {df[id_col].nunique()}개 id → {out.shape[1]-1}개 특성")
    return out, "id"


def engineer_tabular(train_df, label_col, id_col, test_df=None):
    """결측 채움 + 범주형 인코딩. 학습 기준으로 fit 후 동일 적용(누수 방지)."""
    drop = [c for c in [id_col] if c]
    feat_cols = [c for c in train_df.columns if c not in drop + [label_col]]
    # 범주형 인코딩 (train 기준 카테고리)
    cat_cols = [c for c in feat_cols if not pd.api.types.is_numeric_dtype(train_df[c])]
    maps = {}
    for c in cat_cols:
        cats = list(train_df[c].astype(str).unique())
        maps[c] = {v: i for i, v in enumerate(cats)}

    def transform(df):
        X = df[feat_cols].copy()
        for c in cat_cols:
            X[c] = df[c].astype(str).map(maps[c]).fillna(-1)
        X = X.apply(pd.to_numeric, errors="coerce")
        X = X.fillna(X.median(numeric_only=True))
        return X.fillna(0).values.astype(np.float32)

    Xtr = transform(train_df)
    Xte = transform(test_df) if test_df is not None else None
    ok(f"특성 {Xtr.shape[1]}개 (범주형 {len(cat_cols)}개 인코딩)")
    return Xtr, Xte, feat_cols
