"""교차검증 분할 (그룹 유무 자동, fold 수 자동 조정)."""
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, StratifiedGroupKFold
from src.utils.log import ok, warn


def make_folds(y, groups=None, n_folds=5, seed=42):
    y = np.asarray(y)
    if groups is not None:
        groups = np.asarray(groups)
        min_g = int(pd.DataFrame({"y": y, "g": groups}).groupby("y")["g"].nunique().min())
        n = max(2, min(n_folds, min_g))
        if n < n_folds:
            warn(f"클래스별 최소 그룹 {min_g} → fold {n}개로 축소")
        sp = StratifiedGroupKFold(n_splits=n, shuffle=True, random_state=seed)
        it = sp.split(np.zeros(len(y)), y, groups=groups)
    else:
        min_c = int(pd.Series(y).value_counts().min())
        n = max(2, min(n_folds, min_c))
        if n < n_folds:
            warn(f"클래스별 최소 표본 {min_c} → fold {n}개로 축소")
        sp = StratifiedKFold(n_splits=n, shuffle=True, random_state=seed)
        it = sp.split(np.zeros(len(y)), y)
    folds = np.full(len(y), -1)
    for f, (_, va) in enumerate(it):
        folds[va] = f
    ok(f"{n}-fold 분할 완료" + (" (그룹 누수 방지)" if groups is not None else ""))
    return folds, n
