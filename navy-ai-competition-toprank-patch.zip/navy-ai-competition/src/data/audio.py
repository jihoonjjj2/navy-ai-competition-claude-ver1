"""오디오: 스캔 + 세그먼팅 + 스펙트로그램(.npy) + Dataset."""
import random
from pathlib import Path
import numpy as np
import pandas as pd
import librosa
import torch
import torch.nn.functional as Fnn
from torch.utils.data import Dataset
from scipy.signal import butter, filtfilt, hilbert
from src.utils.log import ok, warn, stat


def scan_audio(source_dir, cfg):
    valid = cfg["data"]["valid_classes"]
    exclude = cfg["data"].get("exclude") or []
    source = Path(source_dir)
    rows = []
    for p in source.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".wav", ".flac", ".mp3", ".ogg"}:
            cls = p.parent.name
            if cls in exclude:
                continue
            if valid and cls not in valid:
                continue
            rows.append({"path": str(p), "uid": f"{cls}/{p.name}", "class_name": cls})
    df = pd.DataFrame(rows)
    if len(df) == 0:
        raise RuntimeError(f"오디오 파일이 없습니다: {source}")
    ok(f"오디오 파일 {len(df)}개 / 클래스 {sorted(df['class_name'].unique())}")
    return df


def add_durations(df):
    durs = []
    for p in df["path"]:
        y, sr = librosa.load(p, sr=None, mono=True)
        durs.append(len(y) / sr)
    df = df.copy(); df["duration_sec"] = durs
    return df


def segment(df, cfg):
    seg = cfg["audio"]["segment_seconds"]
    rows = []
    for fid, row in df.reset_index(drop=True).iterrows():
        n = max(1, int(row["duration_sec"] // seg))
        for i in range(n):
            rows.append({"path": row["path"], "uid": row["uid"], "file_id": fid,
                         "offset_sec": i * seg, "class_name": row["class_name"]})
    out = pd.DataFrame(rows)
    stat(f"파일 {len(df)} → 세그먼트 {len(out)}")
    return out


def _resize(spec, size):
    t = torch.tensor(spec, dtype=torch.float32)[None, None]
    t = Fnn.interpolate(t, size=(size, size), mode="bilinear", align_corners=False)
    return t.squeeze().numpy().astype(np.float32)


def _demon(y, cfg):
    f, sr = cfg["audio"], cfg["audio"]["sample_rate"]
    b, a = butter(4, [f["demon_band_low"], f["demon_band_high"]], btype="band", fs=sr)
    env = np.abs(hilbert(filtfilt(b, a, y)))
    return librosa.amplitude_to_db(np.abs(librosa.stft(env, n_fft=f["n_fft_mel"],
                                                        hop_length=f["hop_length"])), ref=np.max)


def spectrogram(y, cfg):
    f = cfg["audio"]
    if f["feature"] == "lofar":
        spec = librosa.amplitude_to_db(np.abs(librosa.stft(
            y, n_fft=f["n_fft_lofar"], hop_length=f["hop_length"])), ref=np.max)
    elif f["feature"] == "mel":
        spec = librosa.power_to_db(librosa.feature.melspectrogram(
            y=y, sr=f["sample_rate"], n_mels=f["n_mels"], n_fft=f["n_fft_mel"],
            hop_length=f["hop_length"], power=2.0), ref=np.max)
    elif f["feature"] == "demon":
        spec = _demon(y, cfg)
    else:
        raise ValueError(f["feature"])
    spec = (spec - spec.mean()) / (spec.std() + 1e-6)
    return _resize(spec, f["img_size"])


def build_specs(seg_df, cfg, processed_dir):
    feat_dir = processed_dir / cfg["audio"]["feature"]
    feat_dir.mkdir(parents=True, exist_ok=True)
    sr, sec = cfg["audio"]["sample_rate"], cfg["audio"]["segment_seconds"]
    tlen = int(sr * sec)
    seg_df = seg_df.reset_index(drop=True).copy()
    paths = []
    n = len(seg_df)
    for i, row in seg_df.iterrows():
        y, _ = librosa.load(row["path"], sr=sr, mono=True, offset=row["offset_sec"], duration=sec)
        if len(y) < tlen:
            y = np.pad(y, (0, tlen - len(y)))
        np.save(feat_dir / f"{i:06d}.npy", spectrogram(y, cfg))
        paths.append(str(feat_dir / f"{i:06d}.npy"))
        if (i + 1) % 200 == 0 or i + 1 == n:
            print(f"  ⚙️ 스펙트로그램 {i+1}/{n}")
    seg_df["npy_path"] = paths
    ok(f"스펙트로그램 {n}개 저장 → {feat_dir}")
    return seg_df


def _spec_aug(spec, nf=2, nt=2, mf=24, mt=32):
    spec = spec.copy(); h, w = spec.shape
    for _ in range(nf):
        f = random.randint(0, mf); f0 = random.randint(0, max(0, h - f)); spec[f0:f0 + f, :] = 0
    for _ in range(nt):
        t = random.randint(0, mt); t0 = random.randint(0, max(0, w - t)); spec[:, t0:t0 + t] = 0
    return spec


class SpecDataset(Dataset):
    def __init__(self, df, augment=False):
        self.df = df.reset_index(drop=True); self.augment = augment

    def __len__(self): return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        spec = np.load(row["npy_path"])
        if self.augment:
            spec = _spec_aug(spec)
        return torch.tensor(spec, dtype=torch.float32).unsqueeze(0), \
            torch.tensor(int(row["target"]), dtype=torch.long)
