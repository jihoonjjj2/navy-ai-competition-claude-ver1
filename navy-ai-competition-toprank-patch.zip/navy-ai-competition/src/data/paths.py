"""데이터 경로 자동 탐색."""
from pathlib import Path
from src.utils.log import ok, warn


def autodetect_source_dir(cfg):
    configured = cfg["data"]["source_dir"]
    if configured and Path(configured).exists():
        return configured
    warn(f"설정 경로 없음: {configured} → 자동 탐색")
    cands = [
        "/content/drive/MyDrive/해군 ai 경진대회 연습/DeepShip-main",
        "/content/drive/MyDrive/수중음향 AI 학습/DeepShip-main",
        "/content/DeepShip-main", "/content/drive/MyDrive/DeepShip-main",
    ]
    for c in cands:
        if Path(c).exists():
            ok(f"자동 감지: {c}"); return c
    md = Path("/content/drive/MyDrive")
    if md.exists():
        for p in md.iterdir():
            if p.is_dir() and ("deepship" in p.name.lower() or "data" in p.name.lower()):
                ok(f"자동 감지: {p}"); return str(p)
    raise FileNotFoundError("데이터 폴더를 찾지 못했습니다. configs에서 source_dir 지정.")
