"""자동 판별 → 모달리티별 파이프라인 라우팅 (완전 자동)."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch

from src.config import load_config  # noqa: F401
from src.utils.seed import seed_everything
from src.utils.log import banner, ok, info, step
from src.utils import viz
from src.data.paths import autodetect_source_dir
from src.detect import resolve_task
from src.data.folds import make_folds
from src.utils.metrics import primary_f1
from src.infer.threshold import tune_threshold
from src.infer.submission import evaluate, finalize, aggregate_audio


def get_dirs(cfg):
    p = Path(cfg["data"]["project_dir"])
    d = {"processed": p / "data/processed", "submissions": p / "data/submissions",
         "outputs": p / "outputs", "figures": p / "outputs/figures"}
    for v in d.values():
        v.mkdir(parents=True, exist_ok=True)
    return d


def _device():
    return "cuda" if torch.cuda.is_available() else "cpu"


# ----------------------------------------------------------------- 오디오/이미지
def _run_deep(cfg, task, source, dirs):
    from src.data import audio as A
    nc_in = 1 if task == "audio_folder" else 3
    if task == "audio_folder":
        df = A.scan_audio(source, cfg)
        df = A.add_durations(df)
        labels = sorted(df["class_name"].unique())
        l2i = {l: i for i, l in enumerate(labels)}
        df["target"] = df["class_name"].map(l2i)
        viz.bar_distribution(df["class_name"].value_counts().to_dict(),
                             "Class Distribution", dirs["figures"] / "class_dist.png")
        viz.hist(df["duration_sec"].values, "Duration", "sec", dirs["figures"] / "duration.png")
        seg = A.segment(df, cfg); seg["target"] = seg["class_name"].map(l2i)
        seg = A.build_specs(seg, cfg, dirs["processed"])
        seg["fold"], n = make_folds(seg["target"].values, groups=seg["file_id"].values,
                                    n_folds=cfg["train"]["n_folds"], seed=cfg["train"]["seed"])
        montage = {c: [np.load(p) for p in seg[seg.class_name == c]["npy_path"].head(3)] for c in labels}
        viz.montage(montage, dirs["figures"] / f"samples_{cfg['audio']['feature']}.png")
        ds = A.SpecDataset
    else:
        from src.data import image as I
        df = I.scan_images(source, cfg)
        labels = sorted(df["class_name"].unique())
        l2i = {l: i for i, l in enumerate(labels)}
        df["target"] = df["class_name"].map(l2i)
        viz.bar_distribution(df["class_name"].value_counts().to_dict(),
                             "Class Distribution", dirs["figures"] / "class_dist.png")
        df["fold"], n = make_folds(df["target"].values, groups=df["file_id"].values,
                                   n_folds=cfg["train"]["n_folds"], seed=cfg["train"]["seed"])
        seg = df; ds = I.ImageDataset

    from src.train.deep import train_deep
    mdir = dirs["outputs"] / cfg["model"]["deep_name"]; mdir.mkdir(parents=True, exist_ok=True)
    oof, history = train_deep(seg, cfg, labels, nc_in, ds, _device(), mdir)
    np.save(mdir / "oof.npy", oof)
    viz.training_curve(history, dirs["figures"] / "training_curve.png")
    nc = len(labels)

    if task == "audio_folder":
        agg = aggregate_audio(seg, oof, nc)
        probs = agg[[f"p{c}" for c in range(nc)]].values
        y_true = agg["true"].values; ids = agg["uid"].values
    else:
        probs, y_true, ids = oof, seg["target"].values, seg["uid"].values

    evaluate(y_true, probs, nc, labels)
    from sklearn.metrics import confusion_matrix
    viz.confusion(confusion_matrix(y_true, probs.argmax(1)), labels,
                  dirs["figures"] / "confusion.png")
    thr = None
    if nc == 2:
        thr, _ = tune_threshold(y_true, probs[:, 1])
    finalize(ids, probs, y_true, nc, labels, labels,
             dirs["submissions"] / f"submission_{cfg['model']['deep_name']}.csv", thr)


# ----------------------------------------------------------------- 표/시퀀스
def _run_tabular(cfg, task, source, dirs):
    from src.data import tabular as Tb
    train_df, label_col, id_col = Tb.load_csv(source, cfg, "train")
    test_df, _, test_id = Tb.load_csv(source, cfg, "test")

    if task == "tabular_sequence":
        train_df, id_col = Tb.engineer_sequence(train_df, id_col, label_col)
        if test_df is not None:
            test_df, test_id = Tb.engineer_sequence(test_df, cfg["data"].get("id_col") or id_col, None)

    # 라벨 인코딩
    labels = sorted(train_df[label_col].astype(str).unique())
    l2i = {l: i for i, l in enumerate(labels)}
    y = train_df[label_col].astype(str).map(l2i).values
    nc = len(labels)
    viz.bar_distribution(pd.Series(y).value_counts().to_dict(),
                         "Label Distribution", dirs["figures"] / "label_dist.png")

    X, Xte, feat_names = Tb.engineer_tabular(train_df, label_col, id_col, test_df)
    folds, n = make_folds(y, groups=None, n_folds=cfg["train"]["n_folds"], seed=cfg["train"]["seed"])

    from src.train.tabular import train_tabular
    oof, imp = train_tabular(X, y, folds, n, cfg, nc)
    mdir = dirs["outputs"] / cfg["model"]["tabular_name"]; mdir.mkdir(parents=True, exist_ok=True)
    np.save(mdir / "oof.npy", oof)
    viz.feature_importance(feat_names, imp, dirs["figures"] / "feature_importance.png")

    evaluate(y, oof, nc, labels)
    from sklearn.metrics import confusion_matrix
    viz.confusion(confusion_matrix(y, oof.argmax(1)), labels, dirs["figures"] / "confusion.png")

    thr = None
    if nc == 2:
        thr, _ = tune_threshold(y, oof[:, 1])

    # 테스트셋이 있으면 그걸로 제출, 없으면 OOF(연습용)
    ids = train_df[id_col].values if id_col in train_df.columns else np.arange(len(y))
    finalize(ids, oof, y, nc, labels, labels,
             dirs["submissions"] / f"submission_{cfg['model']['tabular_name']}_oof.csv", thr)


def run_auto(cfg):
    seed_everything(cfg["train"]["seed"])
    source = autodetect_source_dir(cfg)
    dirs = get_dirs(cfg)
    task = resolve_task(cfg, source)
    if task in ("audio_folder", "image_folder"):
        _run_deep(cfg, task, source, dirs)
    elif task in ("tabular", "tabular_sequence"):
        _run_tabular(cfg, task, source, dirs)
    else:
        raise RuntimeError(f"미지원 task: {task}")
    banner("✅ 전체 완료")
    info(f"제출 파일: {dirs['submissions']}")
    info(f"시각화: {dirs['figures']}")
