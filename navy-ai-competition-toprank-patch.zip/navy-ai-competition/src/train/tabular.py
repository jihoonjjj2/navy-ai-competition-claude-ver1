"""표/시퀀스 k-fold 학습 + OOF + feature importance."""
import numpy as np
from src.models.registry import build_tabular
from src.utils.metrics import primary_f1
from src.utils.log import banner, ok


def train_tabular(X, y, folds, n_folds, cfg, num_classes):
    oof = np.zeros((len(y), num_classes), dtype=np.float32)
    imp = np.zeros(X.shape[1], dtype=np.float64)
    name, seed = cfg["model"]["tabular_name"], cfg["train"]["seed"]
    banner(f"🌲 표 학습 | 모델 {name} | {n_folds}fold")
    scores = []
    for f in range(n_folds):
        tr, va = folds != f, folds == f
        model = build_tabular(name, num_classes, seed)
        model.fit(X[tr], y[tr])
        proba = model.predict_proba(X[va])
        classes = getattr(model, "classes_", np.arange(num_classes))
        oof[np.ix_(np.where(va)[0], np.asarray(classes, dtype=int))] = proba
        if hasattr(model, "feature_importances_"):
            imp += np.asarray(model.feature_importances_, dtype=float)
        vf = primary_f1(y[va], oof[va].argmax(1), num_classes)
        scores.append(vf); print(f"  fold {f+1}/{n_folds} val F1 {vf:.3f}")
    ok(f"평균 F1 {np.mean(scores):.3f}")
    return oof, imp / n_folds
