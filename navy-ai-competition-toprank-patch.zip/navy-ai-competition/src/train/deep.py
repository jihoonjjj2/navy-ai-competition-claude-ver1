"""딥(오디오/이미지) k-fold 학습 + OOF + 학습곡선."""
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.utils.class_weight import compute_class_weight
from src.models.registry import build_deep
from src.utils.metrics import primary_f1
from src.utils.log import banner, ok


def _criterion(y, num_classes, device):
    w = compute_class_weight("balanced", classes=np.arange(num_classes), y=y)
    return nn.CrossEntropyLoss(weight=torch.tensor(w, dtype=torch.float32).to(device))


def _epoch(model, loader, crit, device, opt=None):
    train = opt is not None
    model.train() if train else model.eval()
    tot, ys, ps = 0.0, [], []
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.set_grad_enabled(train):
            logit = model(x); loss = crit(logit, y)
            if train:
                opt.zero_grad(); loss.backward(); opt.step()
        tot += loss.item() * x.size(0)
        ys.extend(y.cpu().numpy()); ps.extend(logit.argmax(1).cpu().numpy())
    return tot / len(loader.dataset), ys, ps


def train_deep(seg_df, cfg, labels, in_chans, dataset_cls, device, ckpt_dir):
    nc = len(labels)
    oof = np.zeros((len(seg_df), nc), dtype=np.float32)
    folds = sorted(seg_df["fold"].unique())
    history, scores = {}, []
    npar = sum(p.numel() for p in build_deep(cfg, nc, in_chans).parameters())
    print(f"📊 모델 {cfg['model']['deep_name']} | {npar/1e6:.1f}M | {len(folds)}fold | {cfg['train']['epochs']}ep")

    for fold in folds:
        banner(f"🔁 Fold {fold+1}/{len(folds)}")
        tr, va = seg_df[seg_df.fold != fold], seg_df[seg_df.fold == fold]
        trl = DataLoader(dataset_cls(tr, cfg, augment=True) if "cfg" in dataset_cls.__init__.__code__.co_varnames
                         else dataset_cls(tr, augment=True),
                         batch_size=cfg["train"]["batch_size"], shuffle=True,
                         num_workers=cfg["train"]["num_workers"])
        val = DataLoader(dataset_cls(va, cfg, augment=False) if "cfg" in dataset_cls.__init__.__code__.co_varnames
                         else dataset_cls(va, augment=False),
                         batch_size=cfg["train"]["batch_size"], shuffle=False,
                         num_workers=cfg["train"]["num_workers"])
        model = build_deep(cfg, nc, in_chans).to(device)
        crit = _criterion(seg_df["target"].values, nc, device)
        opt = torch.optim.AdamW(model.parameters(), lr=cfg["train"]["learning_rate"],
                                weight_decay=cfg["train"]["weight_decay"])
        sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=cfg["train"]["epochs"])
        best, ck, hist_ = -1, ckpt_dir / f"best_fold{fold}.pt", []
        for ep in range(1, cfg["train"]["epochs"] + 1):
            _, ytr, ptr = _epoch(model, trl, crit, device, opt)
            _, yva, pva = _epoch(model, val, crit, device)
            sch.step()
            vf = primary_f1(yva, pva, nc); hist_.append(vf)
            mark = ""
            if vf > best:
                best = vf; torch.save(model.state_dict(), ck); mark = "  💾"
            print(f"  ep {ep:2d} | train F1 {primary_f1(ytr,ptr,nc):.3f} | val F1 {vf:.3f}{mark}")
        history[fold] = hist_; scores.append(best)
        model.load_state_dict(torch.load(ck)); model.eval()
        idx = va.index.to_numpy(); ptr2 = 0
        with torch.no_grad():
            for x, _ in val:
                pr = torch.softmax(model(x.to(device)), 1).cpu().numpy()
                oof[idx[ptr2:ptr2 + len(pr)]] = pr; ptr2 += len(pr)
        ok(f"Fold {fold+1} best F1 {best:.3f}")
    print(f"\n🎯 평균 F1 {np.mean(scores):.3f}")
    return oof, history
