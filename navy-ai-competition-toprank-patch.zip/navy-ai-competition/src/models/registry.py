"""모델 레지스트리. 새 모델 추가가 쉽도록 dict 기반."""


def build_deep(cfg, num_classes, in_chans):
    """오디오/이미지용 timm 모델. cfg.model.deep_name만 바꾸면 됨."""
    import timm
    return timm.create_model(cfg["model"]["deep_name"], pretrained=cfg["model"]["pretrained"],
                             num_classes=num_classes, in_chans=in_chans)


def _lightgbm(nc, seed):
    import lightgbm as lgb
    return lgb.LGBMClassifier(n_estimators=600, learning_rate=0.05, num_leaves=31,
                              subsample=0.8, colsample_bytree=0.8, random_state=seed,
                              class_weight="balanced", verbose=-1)


def _xgboost(nc, seed):
    import xgboost as xgb
    return xgb.XGBClassifier(n_estimators=600, learning_rate=0.05, max_depth=6,
                             subsample=0.8, colsample_bytree=0.8, random_state=seed,
                             eval_metric="mlogloss", tree_method="hist")


def _catboost(nc, seed):
    from catboost import CatBoostClassifier
    return CatBoostClassifier(iterations=600, learning_rate=0.05, depth=6, random_state=seed,
                              verbose=False, auto_class_weights="Balanced")


def _histgb(nc, seed):
    from sklearn.ensemble import HistGradientBoostingClassifier
    return HistGradientBoostingClassifier(max_iter=400, learning_rate=0.05, random_state=seed)


def _randomforest(nc, seed):
    from sklearn.ensemble import RandomForestClassifier
    return RandomForestClassifier(n_estimators=400, random_state=seed, n_jobs=-1,
                                  class_weight="balanced")


TABULAR_REGISTRY = {
    "lightgbm": _lightgbm, "xgboost": _xgboost, "catboost": _catboost,
    "histgb": _histgb, "randomforest": _randomforest,
}


def build_tabular(name, num_classes, seed):
    if name not in TABULAR_REGISTRY:
        raise ValueError(f"미등록 모델: {name}. 가능: {list(TABULAR_REGISTRY)}")
    try:
        return TABULAR_REGISTRY[name](num_classes, seed)
    except ImportError:
        from src.utils.log import warn
        warn(f"{name} 미설치 → histgb(sklearn)로 대체")
        return _histgb(num_classes, seed)
