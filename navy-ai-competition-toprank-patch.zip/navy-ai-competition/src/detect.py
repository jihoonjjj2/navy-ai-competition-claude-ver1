"""데이터 종류 자동 판별 + 라벨/id 컬럼 추정 + 이진/다중 판별."""
from pathlib import Path
import pandas as pd
from src.utils.log import banner, ok, info, warn

AUDIO_EXT = {".wav", ".flac", ".mp3", ".ogg"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
LABEL_NAMES = ["label", "target", "class", "y", "category", "result", "answer"]
ID_NAMES = ["id", "mmsi", "sample_id", "file_id", "uid", "ship_id"]
SEQ_KEYS = ["mmsi", "timestamp", "time", "datetime", "date", "lat", "latitude",
            "lon", "longitude", "sog", "cog", "heading", "speed"]


def _subdirs_have(p, exts):
    for d in p.iterdir():
        if d.is_dir():
            for f in d.rglob("*"):
                if f.is_file() and f.suffix.lower() in exts:
                    return True
    return False


def guess_label_col(df):
    for c in df.columns:
        if c.lower() in LABEL_NAMES:
            return c
    return df.columns[-1]


def guess_id_col(df):
    for c in df.columns:
        if c.lower() in ID_NAMES:
            return c
    return None


def detect_task(source_dir):
    """폴더/파일 구조를 보고 모달리티 자동 판별."""
    p = Path(source_dir)
    if _subdirs_have(p, AUDIO_EXT):
        return "audio_folder"
    if _subdirs_have(p, IMAGE_EXT):
        return "image_folder"
    csvs = sorted(p.glob("*.csv")) + sorted(p.rglob("*.csv"))
    if csvs:
        df = pd.read_csv(csvs[0], nrows=3000)
        cols = [c.lower() for c in df.columns]
        idc = guess_id_col(df)
        has_seq = sum(k in cols for k in SEQ_KEYS) >= 2
        repeats = bool(idc) and df[idc].duplicated().any()
        return "tabular_sequence" if (has_seq or repeats) else "tabular"
    raise RuntimeError("데이터 종류를 자동 판별하지 못했습니다. task.type을 직접 지정하세요.")


def resolve_task(cfg, source_dir):
    banner("🔎 데이터 종류 자동 판별")
    t = cfg["task"]["type"]
    if t == "auto":
        t = detect_task(source_dir)
        ok(f"자동 판별 결과: {t}")
    else:
        info(f"설정에 지정된 종류 사용: {t}")
    explain = {
        "audio_folder": "클래스별 오디오 폴더 → 스펙트로그램 + CNN",
        "image_folder": "클래스별 이미지 폴더 → CNN",
        "tabular": "표 CSV → LightGBM (특성공학 + 5fold)",
        "tabular_sequence": "id+시계열 CSV → id별 특성집계 → LightGBM",
    }
    info(explain.get(t, t))
    return t
