"""이진 분류 임계값 튜닝 (F1 최대화). 2025 대회 핵심 교훈."""
import numpy as np
from sklearn.metrics import f1_score
from src.utils.log import ok


def tune_threshold(y_true, prob_pos):
    best_t, best_f1 = 0.5, -1.0
    for t in np.arange(0.05, 0.96, 0.01):
        f1 = f1_score(y_true, (prob_pos >= t).astype(int))
        if f1 > best_f1:
            best_f1, best_t = f1, t
    ok(f"최적 임계값 {best_t:.2f} (OOF F1 {best_f1:.4f})")
    return float(best_t), float(best_f1)
