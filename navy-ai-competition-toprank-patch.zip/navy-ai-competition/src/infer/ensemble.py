"""여러 모델 OOF 확률 평균 앙상블."""
import numpy as np
from src.utils.metrics import primary_f1
from src.utils.log import banner, ok


def ensemble_oof(oof_list, y_true, num_classes, weights=None):
    banner("🤝 앙상블 (OOF 확률 평균)")
    if weights is None:
        weights = [1.0] * len(oof_list)
    w = np.array(weights) / sum(weights)
    avg = sum(o * wi for o, wi in zip(oof_list, w))
    f1 = primary_f1(y_true, avg.argmax(1), num_classes)
    ok(f"앙상블 F1 {f1:.4f}")
    return avg, f1
