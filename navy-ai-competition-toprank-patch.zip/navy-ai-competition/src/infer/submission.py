"""예측 → (집계) → 임계값/argmax → assert → submission.csv."""
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, classification_report
from src.utils.metrics import primary_f1
from src.utils.log import banner, ok, warn, stat


def aggregate_audio(seg_df, oof, num_classes):
    """오디오: 세그먼트 → 파일 단위 확률 평균."""
    df = seg_df.copy()
    for c in range(num_classes):
        df[f"p{c}"] = oof[:, c]
    pcols = [f"p{c}" for c in range(num_classes)]
    agg = df.groupby("file_id").agg(uid=("uid", "first"), true=("target", "first"),
                                    **{p: (p, "mean") for p in pcols}).reset_index()
    return agg[["uid", "true"]].assign(**{f"p{c}": agg[f"p{c}"] for c in range(num_classes)})


def evaluate(y_true, probs, num_classes, labels):
    banner("📊 OOF 평가")
    pred = probs.argmax(1)
    stat(f"F1 {primary_f1(y_true, pred, num_classes):.4f}")
    print(classification_report(y_true, pred, target_names=labels, zero_division=0))


def finalize(ids, probs, y_true, num_classes, labels, valid_classes, out_path,
             threshold=None):
    banner("🎯 제출 파일 생성")
    if num_classes == 2 and threshold is not None:
        pred = (probs[:, 1] >= threshold).astype(int)
    else:
        pred = probs.argmax(1)
    id2label = {i: l for i, l in enumerate(labels)}
    sub = pd.DataFrame({"id": ids, "label": [id2label[p] for p in pred]})
    assert sub["id"].is_unique, "id 중복"
    assert sub["label"].isin(valid_classes).all(), "라벨 범위 오류"
    assert sub.isnull().sum().sum() == 0, "결측 존재"
    ok("검증 통과 (id 고유 / 라벨 정상 / 결측 없음)")
    sub.to_csv(out_path, index=False)
    ok(f"저장: {out_path}")
    print("\n📊 예측 분포:"); print(sub["label"].value_counts())
    if y_true is not None:
        stat(f"(참고) OOF 기준 F1 {primary_f1(y_true, pred, num_classes):.4f}")
    return sub
