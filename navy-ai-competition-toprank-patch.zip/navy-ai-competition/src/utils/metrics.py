"""평가 지표 (이진/다중 자동)."""
from sklearn.metrics import f1_score, accuracy_score


def primary_f1(y_true, y_pred, num_classes):
    if num_classes == 2:
        return f1_score(y_true, y_pred, average="binary")
    return f1_score(y_true, y_pred, average="macro")


def all_metrics(y_true, y_pred, num_classes):
    return {"accuracy": accuracy_score(y_true, y_pred),
            "f1": primary_f1(y_true, y_pred, num_classes),
            "macro_f1": f1_score(y_true, y_pred, average="macro")}
