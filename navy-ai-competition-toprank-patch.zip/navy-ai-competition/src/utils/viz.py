"""시각화 헬퍼 (모든 그림을 png로 저장)."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from src.utils.log import ok


def _save(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout(); plt.savefig(path, dpi=100); plt.close()
    ok(f"그림 저장: {path}")


def bar_distribution(counts, title, path):
    plt.figure(figsize=(8, 4))
    plt.bar(range(len(counts)), list(counts.values()), color="skyblue", edgecolor="black")
    plt.xticks(range(len(counts)), list(counts.keys()), rotation=45, ha="right")
    plt.title(title); plt.ylabel("count"); _save(path)


def hist(values, title, xlabel, path):
    plt.figure(figsize=(8, 4))
    plt.hist(values, bins=30, color="orange", edgecolor="black")
    plt.title(title); plt.xlabel(xlabel); plt.ylabel("count"); _save(path)


def confusion(cm, labels, path):
    plt.figure(figsize=(6, 5))
    plt.imshow(cm, cmap="Blues")
    plt.title("Confusion Matrix"); plt.xlabel("Predicted"); plt.ylabel("True")
    plt.xticks(range(len(labels)), labels, rotation=45, ha="right")
    plt.yticks(range(len(labels)), labels); plt.colorbar()
    for i in range(len(labels)):
        for j in range(len(labels)):
            plt.text(j, i, int(cm[i, j]), ha="center", va="center")
    _save(path)


def feature_importance(names, importances, path, top=25):
    idx = np.argsort(importances)[::-1][:top]
    plt.figure(figsize=(8, max(4, len(idx) * 0.3)))
    plt.barh(range(len(idx)), importances[idx][::-1], color="seagreen", edgecolor="black")
    plt.yticks(range(len(idx)), [names[i] for i in idx][::-1])
    plt.title("Feature Importance (top)"); plt.xlabel("importance"); _save(path)


def training_curve(history, path):
    plt.figure(figsize=(8, 4))
    for fold, hist_ in history.items():
        ep = range(1, len(hist_) + 1)
        plt.plot(ep, hist_, marker="o", label=f"fold{fold} val F1")
    plt.title("Validation F1 per epoch"); plt.xlabel("epoch"); plt.ylabel("F1")
    plt.legend(); _save(path)


def montage(specs_titles, path, n_per=3):
    labels = list(specs_titles.keys())
    fig, axes = plt.subplots(len(labels), n_per, figsize=(n_per * 3, len(labels) * 3), squeeze=False)
    for r, lab in enumerate(labels):
        arrs = specs_titles[lab][:n_per]
        for c in range(n_per):
            ax = axes[r][c]; ax.axis("off")
            if c < len(arrs):
                ax.imshow(arrs[c], aspect="auto", origin="lower"); ax.set_title(lab, fontsize=10)
    plt.tight_layout(); plt.savefig(path, dpi=100); plt.close()
    ok(f"그림 저장: {path}")
