"""출력 형식 통일."""
def banner(t): print("\n" + "=" * 60); print(t); print("=" * 60)
def ok(m): print(f"✅ {m}")
def warn(m): print(f"⚠️ {m}")
def info(m): print(f"📌 {m}")
def stat(m): print(f"📊 {m}")
def step(m): print(f"\n🔹 {m}")
