"""YAML 로드 + 점표기 오버라이드."""
import yaml


def load_config(path="configs/default.yaml", overrides=None):
    with open(path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if overrides:
        for k, v in overrides.items():
            if v is None:
                continue
            parts = k.split("."); d = cfg
            for p in parts[:-1]:
                d = d[p]
            d[parts[-1]] = v
    return cfg
