# 설정 프리셋 가이드 (대회 주제별)

| 예상 주제 | 데이터 형태 | task.type | 권장 model |
|-----------|------------|-----------|-----------|
| 수중음향 분류 | 클래스별 wav 폴더 | audio_folder(자동) | deep: efficientnet_b2 |
| AIS/항적 의심선박 | id+시계열 CSV | tabular_sequence(자동) | tabular: lightgbm |
| 함정 예지정비 | 센서 시계열 CSV | tabular_sequence/tabular | tabular: lightgbm |
| 사이버 침입탐지 | 표 CSV | tabular(자동) | tabular: lightgbm |
| 이미지 객체/분류 | 클래스별 이미지 폴더 | image_folder(자동) | deep: efficientnet_b2 |

대부분 `task.type: auto`로 두면 자동 판별됩니다. 안 맞으면 직접 지정하세요.
