import sys, os, argparse
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.config import load_config
from src.pipeline import run_auto

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--task", default=None, help="auto/audio_folder/image_folder/tabular/tabular_sequence")
    ap.add_argument("--deep_model", default=None)
    ap.add_argument("--tabular_model", default=None)
    ap.add_argument("--feature", default=None, help="lofar/mel/demon")
    a = ap.parse_args()
    cfg = load_config(a.config, overrides={
        "task.type": a.task, "model.deep_name": a.deep_model,
        "model.tabular_name": a.tabular_model, "audio.feature": a.feature})
    run_auto(cfg)
